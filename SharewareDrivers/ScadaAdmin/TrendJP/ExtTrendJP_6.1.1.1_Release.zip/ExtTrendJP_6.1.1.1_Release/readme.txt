Автор:  Юрий Прадиус 
Расширение предоставляет инструменты для отображения трендов. 
Версия 6.1.1.1 (16.12.2023)

The author: Yuriy Pradius 
The extension provides tools for displaying trends.
Version 6.1.1.1 (12/16/2023)

Project
https://github.com/JurasskPark/RapidScada_v6/tree/master/SharewareDrivers/ScadaAdmin/TrendJP/
Rapid SCADA Forum
https://forum.rapidscada.ru/?topic=ExtTrendJP