Автор:  Юрий Прадиус 
Расширение предоставляет инструменты для отображения трендов. 
Версия 6.1.1.3 (25.12.2023)

The author: Yuriy Pradius 
The extension provides tools for displaying trends.
Version 6.1.1.3 (12/25/2023)

Project
https://github.com/JurasskPark/RapidScada_v6/tree/master/SharewareDrivers/ScadaAdmin/TrendJP/
Rapid SCADA Forum
https://forum.rapidscada.ru/?topic=ExtTrendJP