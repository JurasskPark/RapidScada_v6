Автор:  Юрий Прадиус 
Расширение предоставляет инструменты для отображения трендов. 
Версия 6.3.0.1 (20.10.2024)

The author: Yuriy Pradius 
The extension provides tools for displaying trends.
Version 6.3.0.0 (10/20/2024)

Project
https://github.com/JurasskPark/RapidScada_v6/tree/master/SharewareDrivers/ScadaAdmin/TrendJP/
Rapid SCADA Forum
https://forum.rapidscada.ru/?topic=ExtTrendJP