Автор:  Юрий Прадиус 
Приложение предоставляет инструменты для отображения трендов. 
Версия 6.3.0.2 (09.12.2024)

The author: Yuriy Pradius 
The application provides tools for displaying trends.
Version 6.3.0.2 (12/09/2024)

Project
https://github.com/JurasskPark/RapidScada_v6/tree/master/SharewareDrivers/ScadaAdmin/TrendJP/
Rapid SCADA Forum
https://forum.rapidscada.ru/?topic=ExtTrendJP