Автор:  Юрий Прадиус 
Инструмент для переноса данных из CSV файла в XML проект драйвера SMNP.
Версия 6.1.1.6 (16.04.2024)

The author: Yuriy Pradius 
Tool for transferring data from a CSV file to XML SMNP driver project.
Version 6.1.1.6 (04/16/2024)

Project
https://github.com/JurasskPark/RapidScada_v6/tree/master/SharewareDrivers/ScadaAdmin/SNMP/
Rapid SCADA Forum
https://forum.rapidscada.ru/?topic=ExtSnmpJP