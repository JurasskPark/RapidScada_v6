Автор:  Юрий Прадиус 
Инструмент для проверки работы правильности скрипта до передачи его на сервер.
Версия 6.4.0.0 (23.06.2025)
Внимание! Настройка источника текущих данных обязательная! Без них модуль работать корректно не будет!

The author: Yuriy Pradius 
A tool for checking the correctness of a script before sending it to the server.
Version 6.4.0.0 (06/23/2025)
Attention! Setting up the current data source is mandatory! The module will not work correctly without them!

Project
https://github.com/JurasskPark/RapidScada_v6/tree/master/SharewareDrivers/ScadaAdmin/ScriptCompilerJP/
Rapid SCADA Forum
https://forum.rapidscada.ru/?topic=ExtScriptCompilerJP
https://forum.rapidscada.org/?topic=ExtScriptCompilerJP