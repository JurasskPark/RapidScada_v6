Автор:  Юрий Прадиус 
Инструмент для проверки работы правильности скрипта до передачи его на сервер.
Версия 6.1.1.6 (31.07.2024)

The author: Yuriy Pradius 
A tool for checking the correctness of a script before sending it to the server.
Version 6.1.1.6 (07/31/2024)

Project
https://github.com/JurasskPark/RapidScada_v6/tree/master/SharewareDrivers/ScadaAdmin/ScriptCompilerJP/
Rapid SCADA Forum
https://forum.rapidscada.ru/?topic=ExtScriptCompilerJP