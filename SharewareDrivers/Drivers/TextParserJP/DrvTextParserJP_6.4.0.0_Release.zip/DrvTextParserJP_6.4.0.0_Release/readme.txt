Автор: Юрий Прадиус 
Преобразование текстовых файлов в данные SCADA.
Версия 6.4.0.0 (02.03.2025)

The author: Yuriy Pradius 
Parsing text files to SCADA data.
Version 6.4.0.0 (03/02/2025)

Project
https://github.com/JurasskPark/RapidScada_v6/tree/master/SharewareDrivers
Rapid SCADA Forum
https://forum.rapidscada.org/?topic=DrvTextParserJP
https://forum.rapidscada.ru/?topic=DrvTextParserJP